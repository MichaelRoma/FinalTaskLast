//
//  Post.swift
//  FinalTask
//
//  Created by Mykhailo Romanovskyi on 11.11.2020.
//  Copyright © 2020 e-Legion. All rights reserved.

//Модель для получения данных про посты
struct Post: Codable {
    let id: String
    let description: String
    let image: String
    let createdTime: String
    let currentUserLikesThisPost: Bool
    var likedByCount: Int
    let author: String
    let authorUsername: String
    let authorAvatar: String
    
//    init?(with item: PostData) {
//        self.id = item.id!
//        self.description = item.postDescription!
//        self.image = ""
//        self.createdTime = item.createdTime!
//        self.currentUserLikesThisPost = item.currentUserLikesThisPost
//        self.likedByCount = Int(item.likedByCount!) ?? 0
//        self.author = item.
//        self.authorUsername = item.authorUsername!
//        self.authorAvatar = ""

 //   }
}
