//
//  Filters.swift
//  Course2FinalTask
//
//  Created by Mykhailo Romanovskyi on 02.06.2020.
//  Copyright © 2020 e-Legion. All rights reserved.
//

import Foundation

struct Filters {

    let filterArray = ["CIPhotoEffectChrome", "CIPhotoEffectFade", "CIPhotoEffectNoir", "CIPhotoEffectProcess", "CIPhotoEffectTonal", "CIPhotoEffectTransfer", "CISepiaTone"]
}
